<?php
$icons = sanitize_text_field('', array() );